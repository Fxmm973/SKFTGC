from matplotlib import pyplot as plt
from torch import optim
from prepareData import prepare_data
from model import Model
from trainData import Dataset
from train import train_model, test_model, adjust_learning_rate
import torch
import os
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score
import json
from datetime import datetime
DATA_SAVE_DIR = "curve_data"  # 曲线数据保存目录
# 创建保存目录（不存在则创建）
os.makedirs(DATA_SAVE_DIR, exist_ok=True)

def save_curve_data(y_true, y_score, custom_label=None):
    """
    计算并保存ROC/PR曲线数据
    :param y_true: 真实标签数组
    :param y_score: 预测概率数组
    :param custom_label: 自定义标签（可选）
    """
    # 1. 计算ROC曲线数据
    fpr, tpr, _ = roc_curve(y_true, y_score)
    roc_auc = auc(fpr, tpr)

    # 2. 计算PR曲线数据
    precision, recall, _ = precision_recall_curve(y_true, y_score)
    aupr = average_precision_score(y_true, y_score)

    # 3. 生成数据标识（时间戳 + 自定义标签）
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    if custom_label:
        file_prefix = f"{custom_label}_{timestamp}"
        data_label = custom_label
    else:
        file_prefix = f"curve_{timestamp}"
        data_label = f"Run {timestamp}"

    # 4. 构造数据字典
    curve_data = {
        "label": data_label,
        "timestamp": timestamp,
        "roc": {
            "fpr": fpr.tolist(),
            "tpr": tpr.tolist(),
            "auc": float(roc_auc)
        },
        "pr": {
            "recall": recall.tolist(),
            "precision": precision.tolist(),
            "aupr": float(aupr)
        }
    }

    # 5. 保存为JSON文件
    save_path = os.path.join(DATA_SAVE_DIR, f"{1}.json")
    with open(save_path, "w") as f:
        json.dump(curve_data, f, indent=2)

    print(f"数据保存成功：{save_path}")
    print(f"ROC AUC: {roc_auc:.4f}, PR AUPR: {aupr:.4f}")
    return save_path
class Get_Config(object):
    def __init__(self):
        self.data_path = r'datasets\LBMFF'  # 数据集路径
        self.max_iterations = 10  # 循环次数
        self.test = 50  # 测试次数
        self.save_path = r'datasets\data'
        self.epoch = 100
        self.positive_weight = 0.3 # 越接近1则越不敢预测，越接近0则越敢预测
        self.beta1 = 1
        self.beta2 = 1        
        self.K = 2  # 预处理参数
        self.namda = 0.4  # 预处理参数

class Date_Sizes(object):
    def __init__(self, dataset):
        self.m = dataset['mm']['data'].size(0)  
        self.d = dataset['dd']['data'].size(0)  

def main():
    save_dir = "./best_models"
    os.makedirs(save_dir, exist_ok=True)
    global_best_model_path = os.path.join(save_dir, "global_best_model.pth")  # 仅保存全局最优参数
    # 全局最优指标（仅保留核心）
    global_best = {
        "aupr": 0.0,
        "acc": 0.0,
        "precision": 0.0,
        "recall": 0.0,
        "f1": 0.0,
        "auc": 0.0     # 最优指标所在测试步
    }
    opt = Get_Config()
    # 用来存储每轮的最高ROC AUC
    highest_roc_auc_per_iteration = []  # 记录每轮的最高AUC
    best_roc_auc = 0.0  # 全局最佳AUC
    roc_auc = 0.0   # 当前
    patience = 7.0 # 容忍轮数
    X_best, Y_best = None, None  # 初始化X_best和Y_best
    previous_roc_auc = -float('inf')  # 初始化上一次的ROC AUC为负无穷大

    for j in range(opt.max_iterations):#循环次数10
        dataset = prepare_data(opt)
        train_data = Dataset(opt, dataset)
        sizes = Date_Sizes(dataset)
        model = Model(sizes)
        model.cuda()
        optimizer = optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=1e-5)
        # optimizer = optim.Adam(model.parameters(), lr=0.001, betas=(0.9, 0.999), weight_decay=1e-5)  # 恒定学习率
        highest_roc_auc_this_iteration = 0.0  # 用来存储当前轮次的最高ROC AUC
        no_improvement_count = 0.0  # 记录未提升次数
        patience_counter = 0.0 # 下降次数
        for i in range(opt.test):
            train_model(model, train_data[i], optimizer, opt)
            roc_auc, X_best, Y_best, best_roc_auc,acc_f1, pre_f1, rec_f1, f1_f1,best_threshold_f1,aupr_f1,y_true, y_score = test_model(model, train_data[0], X_best, Y_best, best_roc_auc)
            
            # 更新当前轮次的最高ROC AUC
            if roc_auc >= highest_roc_auc_this_iteration:
                highest_roc_auc_this_iteration = roc_auc 
                no_improvement_count = 0.0  # 重置未提升计数
                if aupr_f1 > global_best["aupr"]:
                    global_best.update({
                    "aupr": aupr_f1,
                    "acc": acc_f1,
                    "precision": pre_f1,
                    "recall": rec_f1,
                    "f1": best_threshold_f1,
                    "auc": roc_auc
                    })
                    save_curve_data(y_true, y_score)
                    # 仅保存全局最优模型参数（覆盖旧文件）
                    torch.save(model.state_dict(), global_best_model_path)
                    print(f"核心指标：AUc={roc_auc:.4f} |AUPR={aupr_f1:.4f} |Acc={acc_f1:.4f} | Precision={pre_f1:.4f} | Recall={rec_f1:.4f} | F1={f1_f1:.4f}")
            else : 
                if roc_auc>previous_roc_auc:
                    no_improvement_count += 0.5
                else:
                    no_improvement_count += 1.0      # 未提升计数加1

            print('0',no_improvement_count)           # 调整学习率    
            patience_counter ,no_improvement_count= adjust_learning_rate(optimizer, roc_auc, previous_roc_auc, 2, patience_counter, no_improvement_count,highest_roc_auc_this_iteration)
            previous_roc_auc = roc_auc
            print(f"Test {i+1} in iteration {j+1} - ROC AUC: {roc_auc}")
            # 检查是否需要早停
            if no_improvement_count > patience:
                print(f"Early stopping at test {i+1} in iteration {j+1}. Best ROC AUC in this iteration: {highest_roc_auc_this_iteration}")
                break

        # 保存当前轮次的最高ROC AUC到列表
        highest_roc_auc_per_iteration.append(highest_roc_auc_this_iteration)

        # 打印当前轮次的最高ROC AUC
        print(f"Highest ROC AUC in iteration {j+1}: {highest_roc_auc_this_iteration}")
        print(f"Best ROC AUC after all iterations: {best_roc_auc}")
    # 输出每轮训练后的最高AUC
    print("Highest ROC AUC per iteration:")
    for i, auc in enumerate(highest_roc_auc_per_iteration, 1):
        print(f"Iteration {i}: {auc}")
    # 输出全局最佳AUC
    print(f"Global Best ROC AUC after all iterations: {best_roc_auc}")
    print("\n===== 训练完成 - 最终全局最优指标 =====")
    print(
        f"全局最优指标：AUC={global_best['auc']:.4f} |AUPR={global_best['aupr']:.4f} |Acc={global_best['acc']:.4f} | Precision={global_best['precision']:.4f} | Recall={global_best['recall']:.4f} | F1={global_best['f1']:.4f}")

    # 最终绘制全局最佳ROC曲线
    if X_best is not None and Y_best is not None:  
        plt.plot(X_best, Y_best, 'k--', label=f'Best ROC (area = {best_roc_auc:.4f})', lw=2)
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title('Best ROC Curve')
        plt.legend(loc="lower right")
        plt.show()

if __name__ == "__main__":
    main()
