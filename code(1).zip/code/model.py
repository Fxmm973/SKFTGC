# import torch as t
# from torch import nn
# from torch_geometric.nn import conv , GATConv



# # 模型Ⅱ 旧
# class Model(nn.Module):
#     def __init__(self, sizes):
#         super(Model, self).__init__()

#         self.m = sizes.m
#         self.d = sizes.d
        
#         self.fg = 256          
#         self.fd = 256
#         self.k = 64
#         self.a =1
#         self.b =0
#         self.c =0

#         # self.beta1 = t.nn.Parameter(t.FloatTensor([1/2]))
#         # self.beta2 = t.nn.Parameter(t.FloatTensor([1/2]))
#         # self.beta1 = t.nn.Parameter(t.FloatTensor([1/3,1/3]))
#         # self.beta2 = t.nn.Parameter(t.FloatTensor([1/3,1/3]))
#         self.beta1 = nn.Parameter(t.FloatTensor([1/3, 1/3]))  
#         self.beta2 = nn.Parameter(t.FloatTensor([1/3, 1/3])) 

#         # 添加GATConv（图注意力层）以增强信息聚合#     多个注意力头的输出拼接（concat=True）生成的输出维度是 64 * 4 = 256。
#         # self.gat_x1 = GATConv(self.fg, 64, heads=4, concat=True)
#         # self.gat_y1 = GATConv(self.fd, 64, heads=4, concat=True)
#         self.gat_x1 = GATConv(self.fg, 256, heads=4, concat=False)
#         self.gat_y1 = GATConv(self.fd, 256, heads=4, concat=False)   
#         # 计算时间增长且为未提升
#         self.gcn_x1 = conv.GCNConv(self.fg, self.fg)    # 两个参数，前面是in_channel，后面是out_channel，也即GCN网络的每个节点的向量长度
#         self.gcn_y1 = conv.GCNConv(self.fd, self.fd)
#         self.gcn_x2 = conv.GCNConv(self.fg, self.fg)
#         self.gcn_y2 = conv.GCNConv(self.fd, self.fd)
#         self.gcn_x3 = conv.GCNConv(self.fg, self.fg)
#         self.gcn_y3 = conv.GCNConv(self.fd, self.fd)

#         # self.gcn_x4 = conv.GCNConv(self.fg, self.fg)    # 两个参数，前面是in_channel，后面是out_channel，也即GCN网络的每个节点的向量长度
#         # self.gcn_y4 = conv.GCNConv(self.fd, self.fd)
#         # self.gcn_x5 = conv.GCNConv(self.fg, 128)
#         # self.gcn_y5 = conv.GCNConv(self.fd, 128)
#         # self.gcn_x6 = conv.GCNConv(128, 64)
#         # self.gcn_y6 = conv.GCNConv(128, 64)



#         self.linear_x_1 = nn.Linear(self.fg, 256)       # 两个参数，相当于前面是in_channel，后面是out_channel
#         self.linear_x_2 = nn.Linear(256, 128)
#         self.linear_x_3 = nn.Linear(128, 64)

#         self.linear_y_1 = nn.Linear(self.fd, 256)
#         self.linear_y_2 = nn.Linear(256, 128)
#         self.linear_y_3 = nn.Linear(128, 64)

#         self.leaky_relu = nn.LeakyReLU(negative_slope=0.01)
 

#     def forward(self, input):
#         t.manual_seed(1)  # 为CPU设置种子

#         # 随机生成miRNA和疾病的特征矩阵
#         x_m = t.randn(self.m, self.fg).cuda()  # miRNA特征矩阵
#         x_d = t.randn(self.d, self.fd).cuda()  # 疾病特征矩阵
#         beta1, beta2 = self.beta1, self.beta2  # 获取beta1和beta2

#         # GCN + GAT 组合特征学习
#         X1 = self.leaky_relu(self.gcn_x1(x_m, input[1]['edge_index'].cuda(), input[1]['data'][input[1]['edge_index'][0], input[1]['edge_index'][1]].cuda()))
#         Y1 = self.leaky_relu(self.gcn_y1(x_d, input[0]['edge_index'].cuda(), input[0]['data'][input[0]['edge_index'][0], input[0]['edge_index'][1]].cuda()))

#         # # 使用GATConv增强图卷积学习
#         # X1 = self.leaky_relu(self.gat_x1(X1, input[1]['edge_index'].cuda()))
#         # Y1 = self.leaky_relu(self.gat_y1(Y1, input[0]['edge_index'].cuda()))

#         # GCN层1
#         X2 = self.leaky_relu(self.gcn_x2(X1, input[1]['edge_index'].cuda(), input[1]['data'][input[1]['edge_index'][0], input[1]['edge_index'][1]].cuda()))
#         Y2 = self.leaky_relu(self.gcn_y2(Y1, input[0]['edge_index'].cuda(), input[0]['data'][input[0]['edge_index'][0], input[0]['edge_index'][1]].cuda()))

#         # GCN层2
#         X3 = self.leaky_relu(self.gcn_x3(X2, input[1]['edge_index'].cuda(), input[1]['data'][input[1]['edge_index'][0], input[1]['edge_index'][1]].cuda()))
#         Y3 = self.leaky_relu(self.gcn_y3(Y2, input[0]['edge_index'].cuda(), input[0]['data'][input[0]['edge_index'][0], input[0]['edge_index'][1]].cuda()))

#         # 线性组合三个层的输出
#         X = beta1[0]*X1 + beta1[1]*X2 + (1-beta1[0]-beta1[1])*X3
#         Y = beta2[0]*Y1 + beta2[1]*Y2 + (1-beta2[0]-beta2[1])*Y3

#         # 全连接层（分别对miRNA和疾病特征进行处理）
#         x1 = self.leaky_relu(self.linear_x_1(X))
#         x2 = self.leaky_relu(self.linear_x_2(x1))
#         x = self.leaky_relu(self.linear_x_3(x2))

#         y1 = self.leaky_relu(self.linear_y_1(Y))
#         y2 = self.leaky_relu(self.linear_y_2(y1))
#         y = self.leaky_relu(self.linear_y_3(y2))

#         # 输出miRNA与疾病之间的关系（通过点积）
#         return x.mm(y.t())



## 性能较好模型
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch_geometric.nn import GATv2Conv, BatchNorm

# class SKConv(nn.Module):
#     def __init__(self, features, WH_ratio=16, M=2):
#         super(SKConv, self).__init__()
#         self.M = M
#         d = max(int(features / WH_ratio), 4)
#         self.fc = nn.Sequential(
#             nn.Linear(features, d),
#             nn.ReLU(inplace=True)
#         )
#         self.fcs = nn.ModuleList([nn.Linear(d, features) for _ in range(M)])
#         self.softmax = nn.Softmax(dim=1)

#     def forward(self, x_list):
#         x = sum(x_list)
#         u = x.mean(dim=0, keepdim=True)  # [1, C]
#         z = self.fc(u)
#         attention_vectors = [fc(z) for fc in self.fcs]
#         attention_vectors = torch.stack(attention_vectors, dim=1)  # [1, M, C]
#         attention_vectors = self.softmax(attention_vectors)
#         out = sum([attention_vectors[0, i] * x_list[i] for i in range(self.M)])
#         return out


# class SKGATLayer(nn.Module):
#     def __init__(self, in_dim, out_dim, num_heads=4, sk_reduction=16):
#         super(SKGATLayer, self).__init__()
#         self.M = 2
#         self.gat_branches = nn.ModuleList([
#             GATv2Conv(in_dim, out_dim, heads=num_heads, concat=True) for _ in range(self.M)
#         ])
#         self.bn = BatchNorm(out_dim * num_heads)
#         self.dropout = nn.Dropout(0.3)
#         self.skconv = SKConv(out_dim * num_heads, WH_ratio=sk_reduction, M=self.M)
#         self.activation = nn.LeakyReLU(0.01)

#     def forward(self, x, edge_index):
#         branch_outputs = [branch(x, edge_index) for branch in self.gat_branches]
#         out = self.skconv(branch_outputs)
#         if out.shape == x.shape:
#             out = out + x  # residual
#         out = self.dropout(self.activation(self.bn(out)))
#         return out


# class Model(nn.Module):
#     def __init__(self, sizes):
#         super(Model, self).__init__()
#         self.m = sizes.m
#         self.d = sizes.d
#         self.fg = 256
#         self.fd = 256

#         self.x_m_init = nn.Parameter(torch.randn(self.m, self.fg))
#         self.x_d_init = nn.Parameter(torch.randn(self.d, self.fd))

#         self.beta1_logits = nn.Parameter(torch.randn(3))
#         self.beta2_logits = nn.Parameter(torch.randn(3))

#         self.skgat_x1 = SKGATLayer(self.fg, 64, num_heads=4)
#         self.skgat_x2 = SKGATLayer(64 * 4, 64, num_heads=4)
#         self.skgat_x3 = SKGATLayer(64 * 4, 64, num_heads=4)

#         self.skgat_y1 = SKGATLayer(self.fd, 64, num_heads=4)
#         self.skgat_y2 = SKGATLayer(64 * 4, 64, num_heads=4)
#         self.skgat_y3 = SKGATLayer(64 * 4, 64, num_heads=4)

#         self.linear_x_1 = nn.Linear(64 * 4, 256)
#         self.linear_x_2 = nn.Linear(256, 128)
#         self.linear_x_3 = nn.Linear(128, 64)

#         self.linear_y_1 = nn.Linear(64 * 4, 256)
#         self.linear_y_2 = nn.Linear(256, 128)
#         self.linear_y_3 = nn.Linear(128, 64)

#         self.leaky_relu = nn.LeakyReLU(0.01)

#     def forward(self, input):
#         x_m = self.x_m_init
#         x_d = self.x_d_init

#         edge_m = input[1]['edge_index'].cuda()
#         edge_d = input[0]['edge_index'].cuda()

#         beta1 = F.softmax(self.beta1_logits, dim=0)
#         beta2 = F.softmax(self.beta2_logits, dim=0)

#         X1 = self.skgat_x1(x_m, edge_m)
#         X2 = self.skgat_x2(X1, edge_m)
#         X3 = self.skgat_x3(X2, edge_m)
#         X = beta1[0]*X1 + beta1[1]*X2 + beta1[2]*X3

#         Y1 = self.skgat_y1(x_d, edge_d)
#         Y2 = self.skgat_y2(Y1, edge_d)
#         Y3 = self.skgat_y3(Y2, edge_d)
#         Y = beta2[0]*Y1 + beta2[1]*Y2 + beta2[2]*Y3

#         x = self.leaky_relu(self.linear_x_1(X))
#         x = self.leaky_relu(self.linear_x_2(x))
#         x = self.leaky_relu(self.linear_x_3(x))

#         y = self.leaky_relu(self.linear_y_1(Y))
#         y = self.leaky_relu(self.linear_y_2(y))
#         y = self.leaky_relu(self.linear_y_3(y))

#         return x.mm(y.t())




## 训练稍慢貌似有上升空间
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch_geometric.nn import GCNConv, GATConv


# class SKConv(nn.Module):
#     def __init__(self, features, WH_ratio=16, M=3):
#         super(SKConv, self).__init__()
#         self.M = M
#         d = max(int(features / WH_ratio), 4)
#         self.fc = nn.Sequential(
#             nn.Linear(features, d),
#             nn.ReLU(inplace=True)
#         )
#         self.fcs = nn.ModuleList([nn.Linear(d, features) for _ in range(M)])
#         self.softmax = nn.Softmax(dim=1)

#     def forward(self, x_list):
#         x_sum = sum(x_list)
#         u = x_sum.mean(dim=0, keepdim=True)  # [1, C]
#         z = self.fc(u)
#         attention_vectors = [fc(z) for fc in self.fcs]
#         attention_vectors = torch.stack(attention_vectors, dim=1)  # [1, M, C]
#         attention_vectors = self.softmax(attention_vectors)

#         out = sum([attention_vectors[0, i] * x_list[i] for i in range(self.M)])
#         return out


# class Model(nn.Module):
#     def __init__(self, sizes):
#         super(Model, self).__init__()
#         self.m = sizes.m
#         self.d = sizes.d
#         self.fg = 256
#         self.fd = 256

#         self.gcn_x1 = GCNConv(self.fg, self.fg)
#         self.gcn_x2 = GCNConv(self.fg, self.fg)
#         self.gcn_x3 = GCNConv(self.fg, self.fg)

#         self.gcn_y1 = GCNConv(self.fd, self.fd)
#         self.gcn_y2 = GCNConv(self.fd, self.fd)
#         self.gcn_y3 = GCNConv(self.fd, self.fd)

#         self.gat_x = GATConv(self.fg, 64, heads=4, concat=True)
#         self.gat_y = GATConv(self.fd, 64, heads=4, concat=True)

#         self.skconv_x = SKConv(self.fg, WH_ratio=16, M=3)
#         self.skconv_y = SKConv(self.fd, WH_ratio=16, M=3)

#         self.beta1 = nn.Parameter(torch.FloatTensor([1/3, 1/3]))
#         self.beta2 = nn.Parameter(torch.FloatTensor([1/3, 1/3]))

#         self.linear_x_1 = nn.Linear(self.fg, 256)
#         self.linear_x_2 = nn.Linear(256, 128)
#         self.linear_x_3 = nn.Linear(128, 64)

#         self.linear_y_1 = nn.Linear(self.fd, 256)
#         self.linear_y_2 = nn.Linear(256, 128)
#         self.linear_y_3 = nn.Linear(128, 64)

#         self.leaky_relu = nn.LeakyReLU(0.01)

#     def forward(self, input):
#         torch.manual_seed(1)
#         x_m = torch.randn(self.m, self.fg).cuda()
#         x_d = torch.randn(self.d, self.fd).cuda()

#         edge_m = input[1]['edge_index'].cuda()
#         edge_d = input[0]['edge_index'].cuda()
#         edge_data_m = input[1]['data'].cuda()
#         edge_attr_m = edge_data_m[edge_m[0], edge_m[1]]
#         edge_data_d = input[0]['data'].cuda()
#         edge_attr_d = edge_data_d[edge_d[0], edge_d[1]]

#         # GCN提取三层
#         X1 = self.leaky_relu(self.gcn_x1(x_m, edge_m, edge_attr_m))
#         X2 = self.leaky_relu(self.gcn_x2(X1, edge_m, edge_attr_m)) + X1  # 残差连接
#         X3 = self.leaky_relu(self.gcn_x3(X2, edge_m, edge_attr_m)) + X2

#         Y1 = self.leaky_relu(self.gcn_y1(x_d, edge_d, edge_attr_d))
#         Y2 = self.leaky_relu(self.gcn_y2(Y1, edge_d, edge_attr_d)) + Y1
#         Y3 = self.leaky_relu(self.gcn_y3(Y2, edge_d, edge_attr_d)) + Y2

#         # β线性融合
#         X_beta = self.beta1[0] * X1 + self.beta1[1] * X2 + (1 - self.beta1[0] - self.beta1[1]) * X3
#         Y_beta = self.beta2[0] * Y1 + self.beta2[1] * Y2 + (1 - self.beta2[0] - self.beta2[1]) * Y3

#         # SKConv融合
#         X_sk = self.skconv_x([X1, X2, X3])
#         Y_sk = self.skconv_y([Y1, Y2, Y3])

#         # 融合两者结果
#         X = 0.5 * X_beta + 0.5 * X_sk
#         Y = 0.5 * Y_beta + 0.5 * Y_sk

#         # 可选 GAT 融合加强全局感知
#         X = self.leaky_relu(self.gat_x(X, edge_m))
#         Y = self.leaky_relu(self.gat_y(Y, edge_d))

#         x = self.leaky_relu(self.linear_x_1(X))
#         x = self.leaky_relu(self.linear_x_2(x))
#         x = self.leaky_relu(self.linear_x_3(x))

#         y = self.leaky_relu(self.linear_y_1(Y))
#         y = self.leaky_relu(self.linear_y_2(y))
#         y = self.leaky_relu(self.linear_y_3(y))

#         return x.mm(y.t())


# 稍逊
# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch_geometric.nn import GCNConv


# class SKConv(nn.Module):
#     def __init__(self, features, WH_ratio=16, M=3):
#         super(SKConv, self).__init__()
#         self.M = M  # 分支数，默认3对应3层GCN输出
#         d = max(int(features / WH_ratio), 4)  # 降维后维度
#         self.fc = nn.Sequential(
#             nn.Linear(features, d),
#             nn.ReLU(inplace=True)
#         )
#         self.fcs = nn.ModuleList([nn.Linear(d, features) for _ in range(M)])  # 每个分支一个全连接层
#         self.softmax = nn.Softmax(dim=1)

#     def forward(self, x_list):
#         # x_list: M 个 [N, C] 特征张量
#         x_sum = sum(x_list)  # [N, C]
#         u = x_sum.mean(dim=0, keepdim=True)  # [1, C] 全局平均池化
#         z = self.fc(u)  # [1, d]
#         attention_vectors = [fc(z) for fc in self.fcs]  # M个 [1, C]
#         attention_vectors = torch.stack(attention_vectors, dim=1)  # [1, M, C]
#         attention_vectors = self.softmax(attention_vectors)  # softmax沿M维度归一化

#         # 对每个节点逐维加权融合各分支特征
#         out = 0
#         for i in range(self.M):
#             # attention_vectors [1, M, C], x_list[i] [N, C]
#             att = attention_vectors[0, i].unsqueeze(0)  # [1, C]
#             out = out + x_list[i] * att  # 广播乘法 [N, C] * [1, C]
#         return out


# class Model(nn.Module):
#     def __init__(self, sizes):
#         super(Model, self).__init__()
#         self.m = sizes.m
#         self.d = sizes.d
#         self.fg = 256
#         self.fd = 256

#         # GCN层
#         self.gcn_x1 = GCNConv(self.fg, self.fg)
#         self.gcn_x2 = GCNConv(self.fg, self.fg)
#         self.gcn_x3 = GCNConv(self.fg, self.fg)

#         self.gcn_y1 = GCNConv(self.fd, self.fd)
#         self.gcn_y2 = GCNConv(self.fd, self.fd)
#         self.gcn_y3 = GCNConv(self.fd, self.fd)

#         # 使用你提供的SKConv融合3层输出
#         self.skconv_x = SKConv(self.fg, WH_ratio=16, M=3)
#         self.skconv_y = SKConv(self.fd, WH_ratio=16, M=3)

#         # 后续全连接层
#         self.linear_x_1 = nn.Linear(self.fg, 256)
#         self.linear_x_2 = nn.Linear(256, 128)
#         self.linear_x_3 = nn.Linear(128, 64)

#         self.linear_y_1 = nn.Linear(self.fd, 256)
#         self.linear_y_2 = nn.Linear(256, 128)
#         self.linear_y_3 = nn.Linear(128, 64)

#         self.leaky_relu = nn.LeakyReLU(0.01)

#     def forward(self, input):
#         torch.manual_seed(1)
#         x_m = torch.randn(self.m, self.fg).cuda()
#         x_d = torch.randn(self.d, self.fd).cuda()

#         edge_m = input[1]['edge_index'].cuda()
#         edge_d = input[0]['edge_index'].cuda()
        
#         data_m = input[1]['data'].cuda()
#         data_d = input[0]['data'].cuda()
#         edge_attr_m = data_m[edge_m[0], edge_m[1]]
#         edge_attr_d = data_d[edge_d[0], edge_d[1]]

#         edge_weight_m = edge_attr_m.squeeze() 
#         edge_weight_d = edge_attr_d.squeeze()

#         X1 = self.leaky_relu(self.gcn_x1(x_m, edge_m, edge_weight=edge_weight_m))
#         X2 = self.leaky_relu(self.gcn_x2(X1, edge_m, edge_weight=edge_weight_m))
#         X3 = self.leaky_relu(self.gcn_x3(X2, edge_m, edge_weight=edge_weight_m))

#         Y1 = self.leaky_relu(self.gcn_y1(x_d, edge_d, edge_weight=edge_weight_d))
#         Y2 = self.leaky_relu(self.gcn_y2(Y1, edge_d, edge_weight=edge_weight_d))
#         Y3 = self.leaky_relu(self.gcn_y3(Y2, edge_d, edge_weight=edge_weight_d))

#         X = self.skconv_x([X1, X2, X3])
#         Y = self.skconv_y([Y1, Y2, Y3])

#         x = self.leaky_relu(self.linear_x_1(X))
#         x = self.leaky_relu(self.linear_x_2(x))
#         x = self.leaky_relu(self.linear_x_3(x))

#         y = self.leaky_relu(self.linear_y_1(Y))
#         y = self.leaky_relu(self.linear_y_2(y))
#         y = self.leaky_relu(self.linear_y_3(y))

#         return x.mm(y.t())




# import torch
# import torch.nn as nn
# import torch.nn.functional as F
# from torch_geometric.nn import GCNConv


# class SKConv(nn.Module):
#     def __init__(self, features, WH_ratio=16, M=3):
#         super(SKConv, self).__init__()
#         self.M = M
#         d = max(int(features / WH_ratio), 4)
#         self.fc = nn.Sequential(
#             nn.Linear(features, d),
#             nn.ReLU(inplace=True)
#         )
#         self.fcs = nn.ModuleList([nn.Linear(d, features) for _ in range(M)])
#         self.softmax = nn.Softmax(dim=1)

#     def forward(self, x_list):
#         x_sum = sum(x_list)  # [N, C]
#         u = x_sum.mean(dim=0, keepdim=True)  # [1, C]
#         z = self.fc(u)  # [1, d]
#         attention_vectors = [fc(z) for fc in self.fcs]  # M x [1, C]
#         attention_vectors = torch.stack(attention_vectors, dim=1)  # [1, M, C]
#         attention_vectors = self.softmax(attention_vectors)
#         out = 0
#         for i in range(self.M):
#             att = attention_vectors[0, i].unsqueeze(0)  # [1, C]
#             out += x_list[i] * att  # broadcast
#         return out


# class MatchingMLP(nn.Module):
#     def __init__(self, input_dim, hidden_dim=128):
#         super(MatchingMLP, self).__init__()
#         self.fc1 = nn.Linear(input_dim, hidden_dim)
#         self.fc2 = nn.Linear(hidden_dim, 1)

#     def forward(self, x, y):
#         diff = torch.abs(x - y)
#         prod = x * y
#         z = torch.cat([x, y, diff, prod], dim=1)
#         z = F.relu(self.fc1(z))
#         return self.fc2(z).squeeze(1)  # [N]


# class Model(nn.Module):
#     def __init__(self, sizes):
#         super(Model, self).__init__()
#         self.m = sizes.m
#         self.d = sizes.d
#         self.fg = 256
#         self.fd = 256

#         self.gcn_x1 = GCNConv(self.fg, self.fg)
#         self.gcn_x2 = GCNConv(self.fg, self.fg)
#         self.gcn_x3 = GCNConv(self.fg, self.fg)

#         self.gcn_y1 = GCNConv(self.fd, self.fd)
#         self.gcn_y2 = GCNConv(self.fd, self.fd)
#         self.gcn_y3 = GCNConv(self.fd, self.fd)

#         self.skconv_x = SKConv(self.fg, WH_ratio=16, M=3)
#         self.skconv_y = SKConv(self.fd, WH_ratio=16, M=3)

#         self.linear_x = nn.Sequential(
#             nn.Linear(self.fg, 128),
#             nn.ReLU(),
#             nn.Linear(128, 64)
#         )

#         self.linear_y = nn.Sequential(
#             nn.Linear(self.fd, 128),
#             nn.ReLU(),
#             nn.Linear(128, 64)
#         )

#         self.match = MatchingMLP(64 * 4)  # [x, y, |x−y|, x⊙y]

#         self.leaky_relu = nn.LeakyReLU(0.01)

#     def forward(self, input):
#         torch.manual_seed(1)
#         x_m = torch.randn(self.m, self.fg).cuda()
#         x_d = torch.randn(self.d, self.fd).cuda()

#         edge_m = input[1]['edge_index'].cuda()
#         edge_d = input[0]['edge_index'].cuda()
#         edge_attr_m = input[1]['data'].cuda()[edge_m[0], edge_m[1]]
#         edge_attr_d = input[0]['data'].cuda()[edge_d[0], edge_d[1]]


#         X1 = self.leaky_relu(self.gcn_x1(x_m, edge_m, edge_attr_m))
#         X2 = self.leaky_relu(self.gcn_x2(X1, edge_m, edge_attr_m))
#         X3 = self.leaky_relu(self.gcn_x3(X2, edge_m, edge_attr_m))
#         Y1 = self.leaky_relu(self.gcn_y1(x_d, edge_d, edge_attr_d))
#         Y2 = self.leaky_relu(self.gcn_y2(Y1, edge_d, edge_attr_d))
#         Y3 = self.leaky_relu(self.gcn_y3(Y2, edge_d, edge_attr_d))

#         X = self.skconv_x([X1, X2, X3])  # [m, fg]
#         Y = self.skconv_y([Y1, Y2, Y3])  # [d, fd]

#         X = self.linear_x(X)  # [m, 64]
#         Y = self.linear_y(Y)  # [d, 64]

#         # 两两组合
#         scores = torch.zeros(self.m, self.d).cuda()
#         for i in range(self.m):
#             scores[i] = self.match(X[i].repeat(self.d, 1), Y)  # broadcasting

#         return scores

# 改造后模型
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GCNConv


class SKConv(nn.Module):
    def __init__(self, features, WH_ratio=16, M=3):
        super(SKConv, self).__init__()
        self.M = M
        d = max(int(features / WH_ratio), 4)
        self.fc = nn.Sequential(
            nn.Linear(features, d),
            nn.ReLU(inplace=True)
        )
        self.fcs = nn.ModuleList([nn.Linear(d, features) for _ in range(M)])
        self.softmax = nn.Softmax(dim=1)

    def forward(self, x_list):
        x_sum = sum(x_list)
        u = x_sum.mean(dim=0, keepdim=True)  # [1, C]
        z = self.fc(u)
        attention_vectors = [fc(z) for fc in self.fcs]
        attention_vectors = torch.stack(attention_vectors, dim=1)  # [1, M, C]
        attention_vectors = self.softmax(attention_vectors)

        out = sum([attention_vectors[0, i] * x_list[i] for i in range(self.M)])
        return out


class Model(nn.Module):
    def __init__(self, sizes):
        super(Model, self).__init__()
        self.m = sizes.m
        self.d = sizes.d
        self.fg = 256
        self.fd = 256

        self.gcn_x1 = GCNConv(self.fg, self.fg)
        self.gcn_x2 = GCNConv(self.fg, self.fg)
        self.gcn_x3 = GCNConv(self.fg, self.fg)

        self.gcn_y1 = GCNConv(self.fd, self.fd)
        self.gcn_y2 = GCNConv(self.fd, self.fd)
        self.gcn_y3 = GCNConv(self.fd, self.fd)

        self.skconv_x = SKConv(self.fg, WH_ratio=16, M=3)
        self.skconv_y = SKConv(self.fd, WH_ratio=16, M=3)

        self.linear_x_1 = nn.Linear(self.fg, 256)
        self.linear_x_2 = nn.Linear(256, 128)
        self.linear_x_3 = nn.Linear(128, 64)

        self.linear_y_1 = nn.Linear(self.fd, 256)
        self.linear_y_2 = nn.Linear(256, 128)
        self.linear_y_3 = nn.Linear(128, 64)

        self.leaky_relu = nn.LeakyReLU(0.01)

    def forward(self, input):
        torch.manual_seed(1)
        x_m = torch.randn(self.m, self.fg).cuda()
        x_d = torch.randn(self.d, self.fd).cuda()

        edge_m = input[1]['edge_index'].cuda()
        edge_d = input[0]['edge_index'].cuda()
        edge_data_m = input[1]['data'].cuda()
        edge_attr_m = edge_data_m[edge_m[0], edge_m[1]]

        edge_data_d = input[0]['data'].cuda()
        edge_attr_d = edge_data_d[edge_d[0], edge_d[1]]


        X1 = self.leaky_relu(self.gcn_x1(x_m, edge_m, edge_attr_m))
        X2 = self.leaky_relu(self.gcn_x2(X1, edge_m, edge_attr_m))
        X3 = self.leaky_relu(self.gcn_x3(X2, edge_m, edge_attr_m))

        Y1 = self.leaky_relu(self.gcn_y1(x_d, edge_d, edge_attr_d))
        Y2 = self.leaky_relu(self.gcn_y2(Y1, edge_d, edge_attr_d))
        Y3 = self.leaky_relu(self.gcn_y3(Y2, edge_d, edge_attr_d))

        # 使用 SKConv 融合 GCN 多层输出
        X = self.skconv_x([X1, X2, X3])
        Y = self.skconv_y([Y1, Y2, Y3])

        x = self.leaky_relu(self.linear_x_1(X))
        x = self.leaky_relu(self.linear_x_2(x))
        x = self.leaky_relu(self.linear_x_3(x))

        y = self.leaky_relu(self.linear_y_1(Y))
        y = self.leaky_relu(self.linear_y_2(y))
        y = self.leaky_relu(self.linear_y_3(y))

        return x.mm(y.t())