from matplotlib import pyplot as plt
import numpy as np
from torch import nn, optim
import torch
from sklearn.metrics import accuracy_score,average_precision_score, precision_score, recall_score, f1_score, roc_curve, auc
from operator import itemgetter
class Get_loss(nn.Module):
    def __init__(self): # lambda_reg
        super(Get_loss, self).__init__()
        # self.lambda_reg = lambda_reg  # 正则化参数
        self.bce_loss = nn.BCEWithLogitsLoss(reduction='none')

    def forward(self, one_index, zero_index, target, input, dd, mm, opt): 
        """
        计算新的损失：包括预测误差和正则化项
        :param one_index: 真实连接的节点对
        :param zero_index: 非连接的节点对
        :param target: 真实标签（评分）
        :param input: 模型预测值
        :param dd, mm: 额外的输入数据（可选）
        :param opt: 配置项
        :return: 计算的损失值
        """
        # 确保标签和预测值设备一致
        target = target.to(input.device)
        if target.dim() != input.dim():
            target = target.view_as(input)  # 维度对齐

        # 1. 计算逐元素交叉熵损失
        ce_loss_matrix = self.bce_loss(input, target)

        # 2. 按正负样本加权求和（与原逻辑对齐）
        # 正样本权重：1 - positive_weight，负样本权重：positive_weight
        pos_loss = (1 - opt.positive_weight) * ce_loss_matrix[one_index].sum()  # 正样本损失
        neg_loss = opt.positive_weight * ce_loss_matrix[zero_index].sum()  # 负样本损失

        # 3. 总损失（可选：除以总样本数，使损失值更稳定）
        total_samples = len(one_index) + len(zero_index)
        total_loss = (pos_loss + neg_loss) / total_samples  # 归一化到样本数

        return total_loss
        # # 计算MSE损失
        # mse_loss = nn.MSELoss(reduction='none')
        # loss_matrix = mse_loss(input, target)
        #
        # # 计算预测误差
        # loss = (1 - opt.positive_weight) * loss_matrix[one_index].sum() + opt.positive_weight * loss_matrix[zero_index].sum()
        #
        # # 计算正则化项 (L2范数正则化)
        # # regularization_loss = self.lambda_reg * (torch.norm(dd, 'fro')**2 + torch.norm(mm, 'fro')**2) / 2
        #
        # # 总损失
        # total_loss = loss #+ regularization_loss
        # return total_loss
    
def train_epoch(model, train_data, optimizer, regression_crit, one_index, zero_index, opt, epoch_losses):  
    """
    训练一个epoch
    """
    model.zero_grad()  # 清零梯度
    score = model(train_data)
    loss = regression_crit(one_index, zero_index, train_data[4].cuda(), score, train_data[0], train_data[1],opt)

    # 记录损失
    epoch_losses.append(loss.item())
    loss.backward()  # 反向传播
    optimizer.step()  # 更新参数
    return loss


def train_model(model, train_data, optimizer, opt):  
    """
    训练整个模型
    """
    model.train()
    regression_crit = Get_loss()
    one_index = train_data[2]['one'].cuda().t().tolist()  # 有联系的节点
    zero_index = train_data[2]['zero'].cuda().t().tolist()
    
    epoch_losses = []  # 存储每个epoch的损失
    for epoch in range(1, opt.epoch + 1):
        loss = train_epoch(model, train_data, optimizer, regression_crit, one_index, zero_index, opt, epoch_losses)
      
    # plt.plot(range(1, opt.epoch + 1), epoch_losses, label='Loss')
    # plt.xlabel('Epoch')
    # plt.ylabel('Loss')
    # plt.title('Loss over Epochs')
    # plt.legend()
    # plt.show()

# def test_model(model, train_data, X_best, Y_best, best_roc_auc):
#     """
#     测试整个模型并计算ROC AUC，同时更新全局最佳ROC AUC和ROC曲线
#     """
#     model.eval()
#     score = model(train_data).tolist()
#     test_index = train_data[2]['test']
#     zero_index = train_data[2]['zero']

#     check = []
#     for i in range(test_index.size(0)):
#         u = test_index[i][0]
#         v = test_index[i][1]
#         check.append([score[u][v], 1])
#     for i in range(zero_index.size(0)):
#         u = zero_index[i][0]
#         v = zero_index[i][1]
#         check.append([score[u][v], 0])

#     X = [0]
#     Y = [0]
#     check = sorted(check, key=itemgetter(0), reverse=True)
#     P, N = 0, 0

#     for i in range(zero_index.size(0) + test_index.size(0)):
#         if check[i][1] == 1:
#             P += 1
#         else:
#             N += 1
#         TP = P
#         FP = i + 1 - P
#         TN = zero_index.size(0) - N
#         FN = test_index.size(0) - P
#         X.append(FP / (TN + FP))  # False Positive Rate
#         Y.append(TP / (TP + FN))  # True Positive Rate
#         # print('TP',TP)
#         # print('FP',FP)
#         # print('TN',TN)
#         # print('FN',FN)
#         #  # 计算 Accuracy, Precision, Recall, F1-score
#         # accuracy = (TP + TN) / (P + N)
#         # precision = TP / (TP + FP) if (TP + FP) > 0 else 0
#         # recall = TP / (TP + FN) if (TP + FN) > 0 else 0
#         # f1 = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0
#     roc_auc = auc(X, Y)
  
   
#     # 如果当前AUC超过全局最佳AUC，更新全局最佳AUC及对应的X, Y
#     if roc_auc > best_roc_auc:
#         best_roc_auc = roc_auc
#         X_best, Y_best = X, Y  # 更新全局最佳ROC曲线
#     #     best_accuracy=accuracy
#     #     best_precision=precision
#     #     best_recall=recall
#     #     best_f1=f1
#     # print('best_accuracy',best_accuracy)
#     # print('best_precision',best_precision)
#     # print('best_recall',best_recall)
#     # print('best_f1',best_f1)    
#     return roc_auc, X_best, Y_best, best_roc_auc
# def test_model(model, train_data, X_best, Y_best, highest_roc_auc_this_iteration):
#     """
#     测试整个模型并计算ROC AUC，同时更新全局最佳ROC AUC和ROC曲线
#     """
#     model.eval()
#     score = model(train_data).cpu().detach().numpy()  # 获取预测分数矩阵并转换为 NumPy 数组

#     # 保存预测分数矩阵到文件
#     np.savetxt('AGCNMC.txt', score, fmt='%10.5f', delimiter=',')
#     print(f"预测分数矩阵已保存到 {'AGCNMC.txt'}")
#     score = model(train_data).tolist()
#     test_index = train_data[2]['test']
#     zero_index = train_data[2]['zero']

  

#     check = []
#     for i in range(test_index.size(0)):
#         u = test_index[i][0]
#         v = test_index[i][1]
#         check.append([score[u][v], 1])
#     for i in range(zero_index.size(0)):
#         u = zero_index[i][0]
#         v = zero_index[i][1]
#         check.append([score[u][v], 0])
#      # 构建预测分数列表
#     check = np.array([[score[u][v], 1] for u, v in test_index] + 
#                      [[score[u][v], 0] for u, v in zero_index])

#     # 按分数降序排序
#     check = check[check[:, 0].argsort()[::-1]]
#     X = [0]
#     Y = [0]
    
#     P, N = 0, 0
#     best_accuracy, best_precision, best_recall, best_f1 = 0.0, 0.0, 0.0, 0.0  
#     for i in range(zero_index.size(0) + test_index.size(0)):
#         if check[i][1] == 1:
#             P += 1
#         else:
#             N += 1
#         TP = P
#         FP = i + 1 - P
#         TN = zero_index.size(0) - N
#         FN = test_index.size(0) - P
#         X.append(FP / (TN + FP))  # False Positive Rate
#         Y.append(TP / (TP + FN))  # True Positive Rate

#     # 计算 AUC
#     roc_auc = auc(X, Y)
#     y_true = [label for _, label in check]  # 真实标签
#     y_scores = [score for score, _ in check]  # 预测分数

#     # 计算最佳阈值（通常取 0.5 或 ROC 曲线最优点）
#     threshold = 0.5 #0.7
#     y_pred = [1 if score >= threshold else 0 for score in y_scores]  # 生成预测标签

#     # 计算混淆矩阵的四个值
#     TP = sum(1 for i in range(len(y_true)) if y_true[i] == 1 and y_pred[i] == 1)
#     FP = sum(1 for i in range(len(y_true)) if y_true[i] == 0 and y_pred[i] == 1)
#     TN = sum(1 for i in range(len(y_true)) if y_true[i] == 0 and y_pred[i] == 0)
#     FN = sum(1 for i in range(len(y_true)) if y_true[i] == 1 and y_pred[i] == 0)

#     # 计算 Accuracy, Precision, Recall, F1-score
#     accuracy = accuracy_score(y_true, y_pred)
#     precision = precision_score(y_true, y_pred, zero_division=0)
#     recall = recall_score(y_true, y_pred, zero_division=0)
#     f1 = f1_score(y_true, y_pred, zero_division=0)

#     print(f'TP: {TP}, FP: {FP}, TN: {TN}, FN: {FN}')
#     # print(f'Accuracy: {accuracy:.4f}')
#     # print(f'Precision: {precision:.4f}')
#     # print(f'Recall: {recall:.4f}')
#     # print(f'F1-score: {f1:.4f}')
#     # 如果当前AUC超过全局最佳AUC，更新全局最佳AUC及对应的X, Y
#     if roc_auc > highest_roc_auc_this_iteration:
#         highest_roc_auc_this_iteration = roc_auc
#         X_best, Y_best = X, Y  # 更新全局最佳ROC曲线
#         best_accuracy,best_precision, best_recall,best_f1 = accuracy,precision,recall, f1
    
#     return roc_auc, X_best, Y_best,highest_roc_auc_this_iteration,best_accuracy,best_precision,best_recall,best_f1


# from sklearn.metrics import roc_auc_score, accuracy_score, precision_score, recall_score, f1_score
# from sklearn.metrics import roc_curve, precision_recall_curve

# def test_model(model, train_data, X_best, Y_best, best_roc_auc):
#     """
#     测试整个模型并计算ROC AUC，同时更新全局最佳ROC AUC和ROC曲线
#     """
#     model.eval()
#     score = model(train_data).tolist()
#     test_index = train_data[2]['test']
#     zero_index = train_data[2]['zero']

#     check = []
#     for i in range(test_index.size(0)):
#         u = test_index[i][0]
#         v = test_index[i][1]
#         check.append([score[u][v], 1])
#     for i in range(zero_index.size(0)):
#         u = zero_index[i][0]
#         v = zero_index[i][1]
#         check.append([score[u][v], 0])

#     # 计算 ROC 曲线
#     X = [0]
#     Y = [0]
#     check = sorted(check, key=itemgetter(0), reverse=True)
#     P, N = 0, 0
#     best_f1 = 0
#     best_threshold_roc = 0
#     best_threshold_f1 = 0

#     y_true = []
#     y_pred_prob = []

#     for i in range(len(check)):
#         if check[i][1] == 1:
#             P += 1
#         else:
#             N += 1
#         TP = P
#         FP = i + 1 - P
#         TN = zero_index.size(0) - N
#         FN = test_index.size(0) - P
#         fpr = FP / (TN + FP)  # False Positive Rate
#         tpr = TP / (TP + FN)  # True Positive Rate
#         X.append(fpr)
#         Y.append(tpr)

#         # 保存真实标签和预测值
#         y_true.append(check[i][1])
#         y_pred_prob.append(check[i][0])

#         # 计算当前的 F1-score
#         precision = TP / (TP + FP) if TP + FP > 0 else 0
#         recall = TP / (TP + FN) if TP + FN > 0 else 0
#         manual_f1_score = 2 * (precision * recall) / (precision + recall) if precision + recall > 0 else 0  # 使用不同变量名

#         # 找到最佳的 F1-score 阈值
#         if manual_f1_score > best_f1:
#             best_f1 = manual_f1_score
#             best_threshold_f1 = check[i][0]

#     # 计算最佳 Youden Index 阈值
#     fpr, tpr, thresholds_roc = roc_curve(y_true, y_pred_prob)
#     youden_index = tpr - fpr
#     best_threshold_roc = thresholds_roc[np.argmax(youden_index)]

#     # 更新全局最好的 ROC AUC
#     roc_auc = auc(X, Y)
#     if roc_auc > best_roc_auc:
#         best_roc_auc = roc_auc
#         X_best = X
#         Y_best = Y

#     # 使用最佳阈值评估
#     y_pred_best_roc = (np.array(y_pred_prob) >= best_threshold_roc).astype(int)
#     y_pred_best_f1 = (np.array(y_pred_prob) >= best_threshold_f1).astype(int)

#     acc_roc = accuracy_score(y_true, y_pred_best_roc)
#     pre_roc = precision_score(y_true, y_pred_best_roc, zero_division=0)
#     recall_roc = recall_score(y_true, y_pred_best_roc, zero_division=0)
#     f1_roc = f1_score(y_true, y_pred_best_roc, zero_division=0)

#     acc_f1 = accuracy_score(y_true, y_pred_best_f1)
#     pre_f1 = precision_score(y_true, y_pred_best_f1, zero_division=0)
#     recall_f1 = recall_score(y_true, y_pred_best_f1, zero_division=0)
#     f1_f1 = f1_score(y_true, y_pred_best_f1, zero_division=0)

#     print(f"Best Threshold (Youden Index): {best_threshold_roc:.4f}")
#     print(f"Best Threshold (F1 Max): {best_threshold_f1:.4f}")
#     print(f"ROC - Accuracy: {acc_roc:.4f}, Precision: {pre_roc:.4f}, Recall: {recall_roc:.4f}, F1: {f1_roc:.4f}")
#     print(f"F1 - Accuracy: {acc_f1:.4f}, Precision: {pre_f1:.4f}, Recall: {recall_f1:.4f}, F1: {f1_f1:.4f}")

#     return roc_auc, X_best, Y_best, best_roc_auc, acc_f1, pre_f1, recall_f1, f1_f1,best_threshold_roc
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, roc_curve, precision_recall_curve
from operator import itemgetter
import numpy as np

def find_best_threshold(y_true, y_pred_prob):
    """
    找到最佳阈值（根据 Youden’s Index 和 F1-score）
    """
    fpr, tpr, thresholds_roc = roc_curve(y_true, y_pred_prob)#计算roc曲线
    youden_index = tpr - fpr
    best_threshold_roc = thresholds_roc[np.argmax(youden_index)]

    precisions, recalls, thresholds_pr = precision_recall_curve(y_true, y_pred_prob)#precision_recall_curve
    f1_scores = 2 * (precisions * recalls) / (precisions + recalls + 1e-9)
    best_threshold_f1 = thresholds_pr[np.argmax(f1_scores)]

    return best_threshold_roc, best_threshold_f1, fpr, tpr

def evaluate_model(y_true, y_pred_prob, threshold):
    """
    根据给定阈值评估模型性能
    """
    y_pred = (np.array(y_pred_prob) >= threshold).astype(int)
    accuracy = accuracy_score(y_true, y_pred)
    precision = precision_score(y_true, y_pred, zero_division=0)
    recall = recall_score(y_true, y_pred, zero_division=0)
    f1 = f1_score(y_true, y_pred, zero_division=0)
    auc_value = roc_auc_score(y_true, y_pred_prob)
    aupr_value = average_precision_score(y_true, y_pred_prob)

    return accuracy, precision, recall, f1, auc_value,aupr_value

def test_model(model, train_data, X_best, Y_best, best_roc_auc, fold_index=None):
    """
    测试模型、计算ROC AUC，并返回各种评估指标与最优阈值
    """
    model.eval()
    score = model(train_data).tolist()
    test_index = train_data[2]['test']
    zero_index = train_data[2]['zero']
    score = model(train_data).cpu().detach().numpy()  # 获取预测分数矩阵并转换为 NumPy 数组

    # # 保存预测分数矩阵到文件
    # np.savetxt('AGCNMC.txt', score, fmt='%10.5f', delimiter=',')
    # print(f"预测分数矩阵已保存到 {'AGCNMC.txt'}")
    y_true = []
    y_pred_prob = []

    for i in range(test_index.size(0)):
        u, v = test_index[i][0], test_index[i][1]
        y_pred_prob.append(score[u][v])
        y_true.append(1)
    for i in range(zero_index.size(0)):
        u, v = zero_index[i][0], zero_index[i][1]
        y_pred_prob.append(score[u][v])
        y_true.append(0)

    # 阈值选择
    best_threshold_roc, best_threshold_f1, fpr, tpr = find_best_threshold(y_true, y_pred_prob)

    # 更新全局最优 ROC 曲线
    roc_auc = roc_auc_score(y_true, y_pred_prob)
    if roc_auc > best_roc_auc:

        best_roc_auc = roc_auc
        X_best = list(fpr)
        Y_best = list(tpr)
        # 保存当前最优预测矩阵
        if fold_index is not None:
            filename = f"AGCNMC_fold{fold_index}.txt"
            np.savetxt(filename, score, fmt='%10.5f', delimiter=',')
            print(f"当前最优分数已保存：{filename}")
    # 评估：使用两个不同的阈值
    acc_roc, pre_roc, rec_roc, f1_roc, auc_roc,aupr_roc = evaluate_model(y_true, y_pred_prob, best_threshold_roc)
    acc_f1, pre_f1, rec_f1, f1_f1, auc_f1,aupr_f1 = evaluate_model(y_true, y_pred_prob, best_threshold_f1)

    print(f"最佳阈值 (Youden’s Index): {best_threshold_roc:.4f}")
    print(f"最佳阈值 (F1-score 最大): {best_threshold_f1:.4f}")
    print(f"[ROC] AUC: {auc_roc:.4f} | Acc: {acc_roc:.4f} | Prec: {pre_roc:.4f} | Recall: {rec_roc:.4f} | F1: {f1_roc:.4f}| AUPR: {aupr_roc:.4f}")
    print(f"[F1 ] AUC: {auc_f1:.4f} | Acc: {acc_f1:.4f} | Prec: {pre_f1:.4f} | Recall: {rec_f1:.4f} | F1: {f1_f1:.4f}| AUPR: {aupr_f1:.4f}")

    return roc_auc, X_best, Y_best, best_roc_auc, acc_f1, pre_f1, rec_f1, f1_f1,best_threshold_f1,aupr_f1,y_true, y_pred_prob
def adjust_learning_rate(optimizer, roc_auc, previous_roc_auc, patience, patience_counter,no_improvement_count,best_roc_auc):
    """
    根据ROC AUC值调整学习率，引入耐心机制
    - patience_counter: 记录已经连续多少轮ROC AUC没有提升
    - previous_roc_auc: 记录上一次的ROC AUC值
    - patience: 当ROC AUC没有提升多少轮时，才减少学习率
    """
    if  roc_auc >= best_roc_auc :    
        patience_counter = 0.0  # 重置耐心计数器
    # if roc_auc >= previous_roc_auc and roc_auc < best_roc_auc :  # 如果AUC提升
    #     patience_counter += 0.5 # 
    else:  # 如果AUC没有提升
        patience_counter += 1.0  # 增加耐心计数器
    print('1',patience_counter)
    print('2',best_roc_auc)   
    print('3',previous_roc_auc)
    print('4',roc_auc)
    # 当耐心计数器达到设定的阈值时，减小学习率
    if patience_counter > patience:
        # 学习率调整策略：逐步减小学习率
        if optimizer.param_groups[0]['lr'] > 0.00001:
            new_lr = optimizer.param_groups[0]['lr'] * 0.7  # 降低学习率
            optimizer.param_groups[0]['lr'] = new_lr
            print(f"Learning rate reduced to {new_lr:.6f}")
        patience_counter = 0  # 重置耐心计数器


    return  patience_counter ,no_improvement_count

